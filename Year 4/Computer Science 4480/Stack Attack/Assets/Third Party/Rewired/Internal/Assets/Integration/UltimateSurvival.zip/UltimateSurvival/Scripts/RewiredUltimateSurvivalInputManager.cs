// Copyright (c) 2017 Augie R. Maddox, Guavaman Enterprises. All rights reserved.

/* The following line must be un-commented for this integration to function, but only after the public functions in
 * Ultimate Survival/Scripts/By Namespace/UltimateSurvival.InputSystem/InputManager.cs have been modified to be virtual.
 */

#pragma warning disable 0219
#pragma warning disable 0618
#pragma warning disable 0649
#pragma warning disable 0414
#pragma warning disable 0162

namespace Rewired.Integration.UltimateSurvival {
    using System;
    using System.Collections.Generic;
    using UnityEngine;

    [RequireComponent(typeof(InputManager))]
    public class RewiredUltimateSurvivalInputManager : global::UltimateSurvival.InputSystem.InputManager {

        #region Consts

        private const string scriptMessagePrefix = "Rewired Ultimate Survival: ";
        private const string rewiredNotInitializedError = scriptMessagePrefix + "Rewired is not initialized. You must have an enabled Rewired Input Manager in the scene.";

        #endregion

        #region Variables

        [SerializeField]
        [Tooltip("The id of the Rewired Player from which to get input.")]
        private int _rewiredPlayerId;

        [SerializeField]
        [Tooltip("Sensitivity multiplier applied to axes converted from absolute coordinates to relative coordinates.")]
        [Utils.Attributes.FieldRange(0f, float.MaxValue)]
        private float _absToRelAxisSensitivity = 1f;

        [SerializeField]
        [Tooltip("The Scroll action.")]
        private ActionMapping _scrollAction = new ActionMapping() { ultimateSurvivalAction = "Mouse ScrollWheel" };

        [SerializeField]
        [Tooltip("Maps Ultimate Survival input actions to Rewired Actions.")]
        private List<ActionMapping> _actionMappings = new List<ActionMapping>();

        private Dictionary<string, ActionMapping> _actionMappingsDictionary = new Dictionary<string, ActionMapping>();
        private Dictionary<string, SpecialAction> _specialActions = new Dictionary<string, SpecialAction>();

        #endregion

        #region Properties

        /// <summary>
        /// The id of the Rewired Player from which to get input.
        /// </summary>
        public virtual int rewiredPlayerId { get { return _rewiredPlayerId; } set { _rewiredPlayerId = value; } }

        /// <summary>
        /// Sensitivity multiplier applied to axes converted from absolute coordinates to relative coordinates.
        /// </summary>
        public virtual float absToRelAxisSensitivity {
            get { return _absToRelAxisSensitivity; }
            set { _absToRelAxisSensitivity = Mathf.Max(0, value); }
        }

        /// <summary>
        /// The action mapping for the Scroll action.
        /// </summary>
        public virtual ActionMapping scrollAction {
            get { return _scrollAction; }
        }

        /// <summary>
        /// Maps Ultimate Survival input actions to Rewired Actions.
        /// </summary>
        public virtual List<ActionMapping> actionMappings {
            get { return _actionMappings ?? (_actionMappings = new List<ActionMapping>()); }
            set {
                _actionMappings = value;
                InitializeActionCache();
            }
        }

        /// <summary>
        /// The action mappings dictionary.
        /// This is used at runtime for action mapping lookups.
        /// </summary>
        protected virtual Dictionary<string, ActionMapping> actionMappingsDictionary {
            get { return _actionMappingsDictionary ?? (_actionMappingsDictionary = new Dictionary<string, ActionMapping>()); }
            set { _actionMappingsDictionary = value; }
        }

        /// <summary>
        /// The Rewired Player from which to get input.
        /// </summary>
        protected virtual Player rewiredPlayer {
            get {
                if(!ReInput.isReady) return null;
                return ReInput.players.GetPlayer(rewiredPlayerId);
            }
        }

        #endregion

        protected virtual void Awake() {
            if(!ReInput.isReady) {
                Debug.LogError(rewiredNotInitializedError);
                return;
            }

            InitializeActionCache();
        }

        protected virtual void Start() { }

        protected virtual void OnEnable() { }

        protected virtual void OnDisable() { }

        protected virtual void OnDestroy() { }

        protected virtual void Update() { }

        public override float GetAxis(string name) {
            if(!ReInput.isReady) return 0f;
            ActionMapping actionMapping = GetRewiredActionMapping(name);
            if(actionMapping == null) return 0f;
            float value;
            if(TryGetSpecialActionAxisValue(name, out value)) return value;
            return ConvertToRelativeAxisIfRequired(actionMapping, rewiredPlayer.GetAxis(actionMapping.rewiredActionId));
        }

        public override float GetAxisRaw(string name) {
            if(!ReInput.isReady) return 0f;
            ActionMapping actionMapping = GetRewiredActionMapping(name);
            if(actionMapping == null) return 0f;
            return ConvertToRelativeAxisIfRequired(actionMapping, rewiredPlayer.GetAxisRaw(actionMapping.rewiredActionId));
        }

        public override bool GetButton(string name) {
            if(!ReInput.isReady) return false;
            ActionMapping actionMapping = GetRewiredActionMapping(name);
            if(actionMapping == null) return false;
            return rewiredPlayer.GetButton(actionMapping.rewiredActionId);
        }

        public override bool GetButtonDown(string name) {
            if(!ReInput.isReady) return false;
            ActionMapping actionMapping = GetRewiredActionMapping(name);
            if(actionMapping == null) return false;
            return rewiredPlayer.GetButtonDown(actionMapping.rewiredActionId);
        }

        public override bool GetButtonUp(string name) {
            if(!ReInput.isReady) return false;
            ActionMapping actionMapping = GetRewiredActionMapping(name);
            if(actionMapping == null) return false;
            return rewiredPlayer.GetButtonUp(actionMapping.rewiredActionId);
        }

        protected virtual void InitializeActionCache() {
            actionMappingsDictionary.Clear();
            _specialActions.Clear();

            if(!ReInput.isReady) {
                Debug.LogError(rewiredNotInitializedError);
                return;
            }

            // Set up special actions
            if(IsValidActionMapping(_scrollAction)) {
                _specialActions.Add(_scrollAction.ultimateSurvivalAction, SpecialAction.Scroll);
                actionMappingsDictionary.Add(_scrollAction.ultimateSurvivalAction, _scrollAction);
            }

            // Set up remaining actions
            int count = actionMappings != null ? actionMappings.Count : 0;
            for(int i = 0; i < count; i++) {
                if(!IsValidActionMapping(_actionMappings[i])) continue;
                if(actionMappingsDictionary.ContainsKey(_actionMappings[i].ultimateSurvivalAction)) {
                    Debug.LogWarning(scriptMessagePrefix + "Duplicate action name found: " + _actionMappings[i].ultimateSurvivalAction + ". This is not allowed.");
                }
                actionMappingsDictionary.Add(actionMappings[i].ultimateSurvivalAction, actionMappings[i]);
            }
        }

        protected virtual float ConvertToRelativeAxisIfRequired(ActionMapping actionMapping, float value) {
            if(value == 0f || actionMapping == null || actionMapping.rewiredActionId < 0) return 0f;

            if(!actionMapping.isRelativeAxis) return value; // does not need to be converted

            // Get the current axis coordinate mode for the Action from the Player
            AxisCoordinateMode axisCoordinateMode = rewiredPlayer.GetAxisCoordinateMode(actionMapping.rewiredActionId);
            if(axisCoordinateMode == AxisCoordinateMode.Relative) return value; // axis is already relative, no conversion required
            
            if(axisCoordinateMode == AxisCoordinateMode.Absolute) {
                value *= Time.unscaledDeltaTime * absToRelAxisSensitivity * 60f;
            }
            return value;
        }

        private bool IsValidActionMapping(ActionMapping mapping) {
            if(mapping == null) return false;
            if(string.IsNullOrEmpty(mapping.ultimateSurvivalAction)) return false;
            InputAction action = ReInput.mapping.GetAction(mapping.rewiredActionId);
            return action != null;
        }

        private ActionMapping GetRewiredActionMapping(string name) {
            ActionMapping actionMapping;
            if(!actionMappingsDictionary.TryGetValue(name, out actionMapping)) return null;
            return actionMapping;
        }

        private bool TryGetSpecialActionAxisValue(string actionName, out float value) {
            SpecialAction specialActionType;
            if(!_specialActions.TryGetValue(actionName, out specialActionType)) {
                value = 0f;
                return false;
            }
            
            switch(specialActionType) {
                case SpecialAction.None:
                    value = 0f;
                    return false;
                case SpecialAction.Scroll:
                    value = GetScrollAxisValue();
                    return true;
                default:
                    throw new NotImplementedException();
            }
        }

        private float GetScrollAxisValue() {
            if(_scrollAction == null || _scrollAction.rewiredActionId < 0) return 0f;

            // Handle input from the mouse wheel as normal since this is the format US expects
            var sources = rewiredPlayer.GetCurrentInputSources(_scrollAction.rewiredActionId);
            for(int i = 0; i < sources.Count; i++) {
                var source = sources[i];
                if(source.controllerType == ControllerType.Mouse &&
                    source.actionElementMap.elementIdentifierId == 2) // mouse wheel
                {
                    return rewiredPlayer.GetAxis(_scrollAction.rewiredActionId);
                }
            }

            // Handle anything else as a button and convert it to an axis value
            if(rewiredPlayer.GetButtonRepeating(_scrollAction.rewiredActionId)) return 1f;
            if(rewiredPlayer.GetNegativeButtonRepeating(_scrollAction.rewiredActionId)) return -1f;

            return 0f;
        }

        private enum SpecialAction {
            None,
            Scroll
        }

        [Serializable]
        public class ActionMapping {
            public string ultimateSurvivalAction;
            public int rewiredActionId = -1;
            public bool isRelativeAxis = false;
        }
    }
}
