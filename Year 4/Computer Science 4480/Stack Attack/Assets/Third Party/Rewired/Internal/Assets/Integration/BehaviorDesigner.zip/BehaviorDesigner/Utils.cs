﻿using System;
using System.Collections.Generic;

namespace Rewired.Integration.BehaviorDesigner {

    public static class Utils {
        public static bool DoesTypeImplement(Type type, Type baseOrInterfaceType) {
#if UNITY_WP_8 || UNITY_WP_8_1 || (UNITY_WSA && NETFX_CORE) || (WINDOWS_UWP && NETFX_CORE)
            return baseOrInterfaceType.GetTypeInfo().IsAssignableFrom(type.GetTypeInfo());
#else
            return baseOrInterfaceType.IsAssignableFrom(type);
#endif
        }
    }
}