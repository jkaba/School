﻿using UnityEngine;
using System.Collections.Generic;

namespace Rewired.Integration.BehaviorDesigner {

    using global::BehaviorDesigner.Runtime;
    using global::BehaviorDesigner.Runtime.Tasks;

    #region Players

    [TaskCategory(Consts.taskCategory_reInput + "/Players")]
    [TaskName("Get Player Count")]
    [TaskDescription("Get the number of Players. Does not include the System Player.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetPlayerCount : GetIntAction {

        protected override TaskStatus DoUpdate() {
            storeValue.Value = ReInput.players.playerCount;
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Players")]
    [TaskName("Get All Players Count")]
    [TaskDescription("Gets the number of Players including the System Player.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetAllPlayersCount : GetIntAction {

        protected override TaskStatus DoUpdate() {
            storeValue.Value = ReInput.players.allPlayerCount;
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Players")]
    [TaskName("Get Players")]
    [TaskDescription("Gets a collection of Players. Does not include the System Player.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetPlayers : GetRewiredObjectListAction {

        protected override TaskStatus DoUpdate() {
            IList<Player> players = ReInput.players.Players;
            int count = players != null ? players.Count : 0;

            for(int i = 0; i < count; i++) {
                workingList.Add(players[i]);
            }

            UpdateStoreValue();
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Players")]
    [TaskName("Get All Players")]
    [TaskDescription("Gets a collection of Players including the System Player.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetAllPlayers : GetRewiredObjectListAction {

        protected override TaskStatus DoUpdate() {
            IList<Player> players = ReInput.players.AllPlayers;
            int count = players != null ? players.Count : 0;

            for(int i = 0; i < count; i++) {
                workingList.Add(players[i]);
            }

            UpdateStoreValue();
            return TaskStatus.Success;
        }
    }

    #endregion

    #region Controllers

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Get Joystick Count")]
    [TaskDescription("The number of joysticks currently connected.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetJoystickCount : GetIntAction {

        protected override TaskStatus DoUpdate() {
            storeValue.Value = ReInput.controllers.joystickCount;
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Get Joysticks")]
    [TaskDescription("Gets a collection of connected Joysticks.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetJoysticks : GetRewiredObjectListAction {

        protected override TaskStatus DoUpdate() {
            IList<Joystick> joysticks = ReInput.controllers.Joysticks;
            int count = joysticks != null ? joysticks.Count : 0;

            for(int i = 0; i < count; i++) {
                workingList.Add(joysticks[i]);
            }

            UpdateStoreValue();
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Get Custom Controller Count")]
    [TaskDescription("The number of custom controllers.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetCustomControllerCount : GetIntAction {
        
        protected override TaskStatus DoUpdate() {
            storeValue.Value = ReInput.controllers.customControllerCount;
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Get Custom Controllers")]
    [TaskDescription("Gets a collection of connected Custom Controllers.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetCustomControllers : GetRewiredObjectListAction {

        protected override TaskStatus DoUpdate() {
            IList<CustomController> customControllers = ReInput.controllers.CustomControllers;
            int count = customControllers != null ? customControllers.Count : 0;

            for(int i = 0; i < count; i++) {
                workingList.Add(customControllers[i]);
            }

            UpdateStoreValue();
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Get Last Active Controller Type")]
    [TaskDescription("Get the last controller type that produced input.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetLastActiveControllerType : GetIntAction {

        protected override TaskStatus DoUpdate() {
            storeValue.Value = (int)ReInput.controllers.GetLastActiveControllerType();
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Is Controller Assigned")]
    [TaskDescription("Is the specified controller assigned to any players?")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredIsControllerAssigned : ControllerGetBoolAction {

        protected override TaskStatus DoUpdate() {
            if(!HasController) return TaskStatus.Failure;
            UpdateStoreValue(ReInput.controllers.IsControllerAssigned(Controller.type, Controller));
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Is Controller Assigned To Player")]
    [TaskDescription("Is the specified controller assigned to the specified player?")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredIsControllerAssignedToPlayer : ControllerGetBoolAction {

        [RequiredField]
        [Tooltip("The Rewired Player Id. To use the System Player, enter any value < 0 or 9999999.")]
        public SharedInt playerId;

        public override void OnReset() {
            base.OnReset();
            playerId = 0;
        }

        protected override TaskStatus DoUpdate() {
            if(!HasController) return TaskStatus.Failure;
            UpdateStoreValue(ReInput.controllers.IsControllerAssignedToPlayer(Controller.type, Controller.id, playerId.Value));
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Remove Controller From All Players")]
    [TaskDescription("De-assigns the specified controller from all players.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredRemoveControllerFromAllPlayers : ControllerAction {

        [Tooltip("Do we de-assign from the System player also?")]
        public SharedBool includeSystemPlayer = true;

        public override void OnReset() {
            base.OnReset();
            includeSystemPlayer = true;
        }

        protected override TaskStatus DoUpdate() {
            if(!HasController) return TaskStatus.Failure;
            ReInput.controllers.RemoveControllerFromAllPlayers(Controller.type, Controller.id, includeSystemPlayer.Value);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Auto Assign Joystick")]
    [TaskDescription("Auto-assigns a Joystick to a Player based on the joystick auto-assignment settings in the Rewired Input Manager. If the Joystick is already assigned to a Player, the Joystick will not be re-assigned.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredAutoAssignJoystick : JoystickAction {

        protected override TaskStatus DoUpdate() {
            ReInput.controllers.AutoAssignJoystick(Joystick);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Auto Assign Joysticks")]
    [TaskDescription("Auto-assigns all unassigned Joysticks to Players based on the joystick auto-assignment settings in the Rewired Input Manager.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredAutoAssignJoysticks : JoystickAction {

        protected override TaskStatus DoUpdate() {
            ReInput.controllers.AutoAssignJoysticks();
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Create Custom Controller")]
    [TaskDescription("Create a new CustomController object from a source definition in the Rewired Input Manager.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredCreateCustomController : GetRewiredObjectAction {

        [Tooltip("Source id of the CustomController definition.")]
        public SharedInt sourceId;

        [Tooltip("Tag to assign.")]
        public SharedString tag;

        protected override TaskStatus DoUpdate() {
            CustomController cc;
            if(!string.IsNullOrEmpty(tag.Value)) {
                cc = ReInput.controllers.CreateCustomController(sourceId.Value, tag.Value);
            } else {
                cc = ReInput.controllers.CreateCustomController(sourceId.Value);
            }

            if(cc != null) UpdateStoreValue(new RewiredObject(cc));
            else UpdateStoreValue(null);

            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Destroy Custom Controller")]
    [TaskDescription("Destroys a CustomController.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredDestroyCustomController : CustomControllerAction {

        protected override TaskStatus DoUpdate() {
            if(!HasController) return TaskStatus.Failure;
            ReInput.controllers.DestroyCustomController(Controller);
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Get Any Button")]
    [TaskDescription("Get the button held state of all buttons on all controllers. Returns TRUE if any button is held. This retrieves the value from the actual hardware buttons, not Actions as mapped by Controller Maps in Player.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetAnyButton : GetBoolAction {

        [Tooltip("If enabled, the button state will be obtained only for controllers matching the chosen Controller Type.")]
        public bool useControllerType;

        [Tooltip("The type of controller. This is ignored if Use Controller Type is false.")]
        public ControllerType controllerType = ControllerType.Keyboard;

        public override void OnReset() {
            base.OnReset();
            useControllerType = false;
            controllerType = ControllerType.Keyboard;
        }

        protected override TaskStatus DoUpdate() {
            if(useControllerType) ReInput.controllers.GetAnyButton(controllerType);
            else ReInput.controllers.GetAnyButton();
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Get Any Button Down")]
    [TaskDescription("Get the button just pressed state of all buttons on all controllers. This will only return TRUE only on the first frame a button is pressed. This retrieves the value from the actual hardware buttons, not Actions as mapped by Controller Maps in Player.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetAnyButtonDown : GetBoolAction {

        [Tooltip("If enabled, the button state will be obtained only for controllers matching the chosen Controller Type.")]
        public bool useControllerType;

        [Tooltip("The type of controller. This is ignored if Use Controller Type is false.")]
        public ControllerType controllerType = ControllerType.Keyboard;

        public override void OnReset() {
            base.OnReset();
            useControllerType = false;
            controllerType = ControllerType.Keyboard;
        }

        protected override TaskStatus DoUpdate() {
            if(useControllerType) ReInput.controllers.GetAnyButtonDown(controllerType);
            else ReInput.controllers.GetAnyButtonDown();
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Get Any Button Up")]
    [TaskDescription("Get the button just released state of all buttons on all controllers of a specified type. This will only return TRUE only on the first frame a button is released. This retrieves the value from the actual hardware buttons, not Actions as mapped by Controller Maps in Player.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetAnyButtonUp : GetBoolAction {

        [Tooltip("If enabled, the button state will be obtained only for controllers matching the chosen Controller Type.")]
        public bool useControllerType;

        [Tooltip("The type of controller. This is ignored if Use Controller Type is false.")]
        public ControllerType controllerType = ControllerType.Keyboard;

        public override void OnReset() {
            base.OnReset();
            useControllerType = false;
            controllerType = ControllerType.Keyboard;
        }

        protected override TaskStatus DoUpdate() {
            if(useControllerType) ReInput.controllers.GetAnyButtonUp(controllerType);
            else ReInput.controllers.GetAnyButtonUp();
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Get Any Button Prev")]
    [TaskDescription("Get the previous button held state of all buttons on all controllers. Returns TRUE if any button was held in the previous frame. This retrieves the value from the actual hardware buttons, not Actions as mapped by Controller Maps in Player.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetAnyButtonPrev : GetBoolAction {

        [Tooltip("If enabled, the button state will be obtained only for controllers matching the chosen Controller Type.")]
        public bool useControllerType;

        [Tooltip("The type of controller. This is ignored if Use Controller Type is false.")]
        public ControllerType controllerType = ControllerType.Keyboard;

        public override void OnReset() {
            base.OnReset();
            useControllerType = false;
            controllerType = ControllerType.Keyboard;
        }

        protected override TaskStatus DoUpdate() {
            if(useControllerType) ReInput.controllers.GetAnyButtonPrev(controllerType);
            else ReInput.controllers.GetAnyButtonPrev();
            return TaskStatus.Success;
        }
    }

    [TaskCategory(Consts.taskCategory_reInput + "/Controllers")]
    [TaskName("Get Any Button Changed")]
    [TaskDescription("Returns true if any button has changed state from the previous frame to the current. This retrieves the value from the actual hardware buttons, not Actions as mapped by Controller Maps in Player.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetAnyButtonChanged : GetBoolAction {

        [Tooltip("If enabled, the button state will be obtained only for controllers matching the chosen Controller Type.")]
        public bool useControllerType;

        [Tooltip("The type of controller. This is ignored if Use Controller Type is false.")]
        public ControllerType controllerType = ControllerType.Keyboard;

        public override void OnReset() {
            base.OnReset();
            useControllerType = false;
            controllerType = ControllerType.Keyboard;
        }

        protected override TaskStatus DoUpdate() {
            if(useControllerType) ReInput.controllers.GetAnyButtonChanged(controllerType);
            else ReInput.controllers.GetAnyButtonChanged();
            return TaskStatus.Success;
        }
    }

    #endregion

    #region Time

    [TaskCategory(Consts.taskCategory_reInput + "/Time")]
    [TaskName("Get Unscaled Time")]
    [TaskDescription("Current unscaled time since start of the game. Always use this when doing current time comparisons for button and axis active/inactive times instead of Time.time or Time.unscaledTime.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredGetUnscaledTime : GetFloatAction {

        protected override TaskStatus DoUpdate() {
            storeValue.Value = ReInput.time.unscaledTime;
            return TaskStatus.Success;
        }
    }

    #endregion

    #region Events

    [TaskCategory(Consts.taskCategory_events)]
    [TaskName("Controller Connected Event")]
    [TaskDescription("Event triggered when a controller is conected.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerConnectedEvent : Conditional {

        [Tooltip("Store the result in a string variable.")]
        public SharedString storeControllerName;

        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeControllerId = -1;

        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeControllerType = 0;

        private bool hasEvent = false;

        public override void OnAwake() {
            base.OnAwake();
            ReInput.ControllerConnectedEvent += OnControllerConnected;
        }

        public override void OnReset() {
            base.OnReset();
            storeControllerName = string.Empty;
            storeControllerId = -1;
            storeControllerType = 0;
            hasEvent = false;
        }

        public override void OnBehaviorComplete() {
            ReInput.ControllerDisconnectedEvent -= OnControllerConnected;
        }

        public override TaskStatus OnUpdate() {
            
            return DoUpdate();
        }

        public TaskStatus DoUpdate() {
            if(!hasEvent) return TaskStatus.Failure;
            hasEvent = false;
            return TaskStatus.Success;
        }

        private void OnControllerConnected(ControllerStatusChangedEventArgs args) {
            hasEvent = true;
            storeControllerName.Value = args.name;
            storeControllerId.Value = args.controllerId;
            storeControllerType.Value = (int)args.controllerType;
        }
    }

    [TaskCategory(Consts.taskCategory_events)]
    [TaskName("Controller PreDisconnect Event")]
    [TaskDescription("Event triggered just before a controller is disconnected. You can use this event to save controller maps before the controller is removed.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerPreDisconnectEvent : Conditional {

        [Tooltip("Store the result in a string variable.")]
        public SharedString storeControllerName;

        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeControllerId = -1;

        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeControllerType = 0;

        private bool hasEvent = false;

        public override void OnAwake() {
            base.OnAwake();
            ReInput.ControllerPreDisconnectEvent += OnControllerPreDisconnect;
        }

        public override void OnReset() {
            base.OnReset();
            storeControllerName = string.Empty;
            storeControllerId = -1;
            storeControllerType = 0;
            hasEvent = false;
        }

        public override void OnBehaviorComplete() {
            ReInput.ControllerPreDisconnectEvent -= OnControllerPreDisconnect;
        }

        public override TaskStatus OnUpdate() {
            return DoUpdate();
        }

        public TaskStatus DoUpdate() {
            if(!hasEvent) return TaskStatus.Failure;
            hasEvent = false;
            return TaskStatus.Success;
        }

        private void OnControllerPreDisconnect(ControllerStatusChangedEventArgs args) {
            hasEvent = true;
            storeControllerName.Value = args.name;
            storeControllerId.Value = args.controllerId;
            storeControllerType.Value = (int)args.controllerType;
        }
    }

    [TaskCategory(Consts.taskCategory_events)]
    [TaskName("Controller Disconnected Event")]
    [TaskDescription("Event triggered after a controller is disconnected.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredControllerDisconnectedEvent : Conditional {

        [Tooltip("Store the result in a string variable.")]
        public SharedString storeControllerName;

        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeControllerId = -1;

        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeControllerType = 0;

        private bool hasEvent = false;

        public override void OnAwake() {
            base.OnAwake();
            ReInput.ControllerDisconnectedEvent += OnControllerDisconnected;
        }

        public override void OnReset() {
            base.OnReset();
            storeControllerName = string.Empty;
            storeControllerId = -1;
            storeControllerType = 0;
            hasEvent = false;
        }

        public override void OnBehaviorComplete() {
            ReInput.ControllerDisconnectedEvent -= OnControllerDisconnected;
        }

        public override TaskStatus OnUpdate() {
            return DoUpdate();
        }

        public TaskStatus DoUpdate() {
            if(!hasEvent) return TaskStatus.Failure;
            hasEvent = false;
            return TaskStatus.Success;
        }

        private void OnControllerDisconnected(ControllerStatusChangedEventArgs args) {
            hasEvent = true;
            storeControllerName.Value = args.name;
            storeControllerId.Value = args.controllerId;
            storeControllerType.Value = (int)args.controllerType;
        }
    }

    [TaskCategory(Consts.taskCategory_events)]
    [TaskName("Last Active Controller Changed Event")]
    [TaskDescription("Event triggered every time the last active controller changes.")]
    [TaskIcon(Consts.taskIconPath)]
    public class RewiredLastActiveControllerChangedEvent : Conditional {

        [Tooltip("Store the result in a string variable.")]
        public SharedString storeControllerName;

        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeControllerId = -1;

        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeControllerType = 0;

        private bool hasEvent = false;

        public override void OnAwake() {
            base.OnAwake();
            ReInput.controllers.AddLastActiveControllerChangedDelegate(OnLastActiveControllerChanged);
        }

        public override void OnReset() {
            base.OnReset();
            storeControllerName = string.Empty;
            storeControllerId = -1;
            storeControllerType = 0;
            hasEvent = false;
        }

        public override void OnBehaviorComplete() {
            ReInput.controllers.RemoveLastActiveControllerChangedDelegate(OnLastActiveControllerChanged);
        }

        public override TaskStatus OnUpdate() {
            return DoUpdate();
        }

        public TaskStatus DoUpdate() {
            if(!hasEvent) return TaskStatus.Failure;
            hasEvent = false;
            return TaskStatus.Success;
        }

        private void OnLastActiveControllerChanged(Controller controller) {
            hasEvent = true;
            storeControllerName = controller.name;
            storeControllerType.Value = (int)controller.type;
            storeControllerId = controller.id;
        }
    }

    #endregion
}
